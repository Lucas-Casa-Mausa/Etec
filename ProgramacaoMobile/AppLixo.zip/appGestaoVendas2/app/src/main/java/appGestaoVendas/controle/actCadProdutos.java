package appGestaoVendas.controle;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.strictmode.LeakedClosableViolation;
import android.os.strictmode.WebViewMethodCalledOnWrongThreadViolation;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import util.DbGestaoVendas;


        public class actCadProdutos extends AppCompatActivity{
        EditText edtCodigo,edtProduto, edtQuantidade,edtPreco,edtCusto,edtDescricao;
        Button btnCadastrar,btnExcluir,btnConsultar,btnAlterar;

        private int codigo=0;

        DbGestaoVendas dbGestaoVendas = null;
        SQLiteDatabase db = null;
        ContentValues valores = null;
        Cursor cursor;

        @Override
        protected  void onCreate(Bundle savedInstanceState){
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_tela_principal);
            edtCodigo=findViewById(R.id.edtCodigo);
            edtProduto=findViewById(R.id.edtProduto);
            edtQuantidade=findViewById(R.id.edtQuantidade);
            edtCusto=findViewById(R.id.edtCusto);
            edtPreco=findViewById(R.id.edtPreco);
            edtDescricao=findViewById(R.id.edtDescricao);
            btnAlterar=findViewById(R.id.btnAlterar);
            btnCadastrar=findViewById(R.id.btnCadastrar);
            btnConsultar=findViewById(R.id.btnConsultar);
            btnExcluir=findViewById(R.id.btnExcluir);
            dbGestaoVendas = new DbGestaoVendas(getBaseContext());
        }
        public void Limpar(View view){
            edtProduto.setText("null");
            edtQuantidade.setText("null");
            edtCodigo.setText("");
        }



    public void Cadastrar(View view) {
        db = dbGestaoVendas.getWritableDatabase();
        valores = new ContentValues();
        valores.put("produto", edtProduto.getText().toString());
        valores.put("codigo", edtCodigo.getText().toString());
        valores.put("preco",edtPreco.getText().toString());
        valores.put("custo",edtCusto.getText().toString());
        valores.put("descricao",edtDescricao.getText().toString());
        valores.put("estoque",edtQuantidade.getText().toString());
        double linha = db.insert("Produtos", null, valores);
        if (linha == 0) {
            Toast.makeText(this, "Falha ao cadastrar", Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(this, "Cadastro realizado com Sucesso", Toast.LENGTH_LONG).show();
        }
        db.close();
        Limpar(view);
    }




    }


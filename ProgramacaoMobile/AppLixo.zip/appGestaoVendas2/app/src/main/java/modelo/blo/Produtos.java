package modelo.blo;
public class Produtos {
    private int codigo;
    private String produto;
    private Float custo;
    private String descricao;
    private Float preco;
    private int quantidade;


    public Produtos( int codigo, String produto,Float custo,Float preco,String descricao,int quantidade){
        this.codigo=codigo;
        this.produto=produto;
        this.custo=custo;
        this.preco =preco;
        this.quantidade=quantidade;
        this.descricao=descricao;
    }

    public Produtos(){}

    public void setCodigo(int codigo){
        this.codigo=codigo;
    }
    public int getCodigo(){
        return codigo;
    }

    public String getProduto(){
        return produto;
    }
    public void setProduto(){
        this.produto= produto;
    }

    public Float getCusto(){
        return custo;
    }
    public void setCusto(){
        this.custo= custo;
    }

    public int getQuantidade(){
        return quantidade;
    }
    public void setQuantidade(){
        this.quantidade =quantidade;
    }

    public float getPreco(){
        return preco;
    }
    public void setPreco(){
        this.preco=preco;
    }

    public String getDescricao(){
        return descricao;
    }
    public void setDescricao(){
        this.descricao=descricao;
    }




}

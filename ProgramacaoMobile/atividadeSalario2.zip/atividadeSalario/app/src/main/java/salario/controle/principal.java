package salario.controle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;


public class principal extends AppCompatActivity {
    TextView txtNome, txtSalario,txtExibir;
    RadioButton rdbAuxiliar,rdbTecnico,rdbEngenheiro;
    EditText edtNome,edtSalarioAtual;
    int indice=0;

    String[] nome=new String[4];
    float[] salarioatual = new float[4];
    float[] salarioReajuste = new float[4];
    String[] cargo= new String[3];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
        txtNome=findViewById(R.id.txtNome);
        txtSalario=findViewById(R.id.txtSalario);

        edtNome=findViewById(R.id.edtNome);
        edtSalarioAtual=findViewById(R.id.edtSalarioAtual);

        rdbAuxiliar=findViewById(R.id.rdbAuxiliar);
        rdbEngenheiro=findViewById(R.id.rdbEngenheiro);
        rdbTecnico=findViewById(R.id.rdbTecnico);
    }
    public void Cadastrar(View view){
        if (indice<=4){
            Toast.makeText(this,"Cadastro no indice:"+ indice,Toast.LENGTH_LONG).show();
            nome[indice]=edtNome.getText().toString();
            salarioatual[indice] = Float.parseFloat(edtSalarioAtual.getText().toString());
            if(salarioatual[indice]>=1500){
            salarioReajuste[indice]= (float) (salarioatual[indice]*0.08);
            }
            else{
                salarioReajuste[indice]=(float)( salarioatual[indice]*0.10);
            }
            indice++;
        }
    }
    public void Exibir(View view){
      

        indice++;

        txtExibir.setText("Nome: "+ edtNome + "\nsalário sem reajuste " + salarioatual + "\nsalario com reajuste" + salarioReajuste
        + "\nCargo: " + cargo);

    }
}
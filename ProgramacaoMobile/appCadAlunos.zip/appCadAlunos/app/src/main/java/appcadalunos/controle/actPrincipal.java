package appcadalunos.controle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class actPrincipal extends AppCompatActivity {
 TextView txtNome, txtCelular, txtEmail, txtExibir;
 EditText edtNome, edtCelular, edtEmail;
 Button btnIdioma;
    int indice = 0;

    //nome[0], nome[1], nome [2]
    String[] nome = new String[4];
    //celiular[0], celular[1], celular[2]
    String[] celular = new String[3];
    //email[0], email[1], email[2]
    String[] email = new String[3];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act_principal);
        txtNome=findViewById(R.id.txtNome);
        txtCelular=findViewById(R.id.txtCelular);
        txtEmail=findViewById(R.id.txtEmail);

        edtNome=findViewById(R.id.edtNome);
        edtCelular=findViewById(R.id.edtCelular);
        edtEmail=findViewById(R.id.edtEmail);

        btnIdioma=findViewById(R.id.btnIdioma);
        txtExibir=findViewById(R.id.txtExibir);

    }
    public void AlterarIdioma(View view) {
        if (btnIdioma.getText().toString().equals("En")) {
            btnIdioma.setText("Br");
            txtNome.setText(R.string.txtNome);

        } else {
            btnIdioma.setText("En");
            txtNome.setText(R.string.txtNomeEn);
        }
    }

        public void Cadastrar(View view){
        if(indice<=2){
            Toast.makeText(this,"Cadastro Indice:"+ indice, Toast.LENGTH_LONG).show();
        nome[indice] =edtNome.getText().toString();
        celular[indice] =edtCelular.getText().toString();
        email[indice] = edtEmail.getText().toString();
        indice++;

        edtNome.setText("");
        edtCelular.setText("");
        edtEmail.setText("");
        edtNome.requestFocus();
        }
      else{
            Toast.makeText( this,"Cadastros já Realizados",Toast.LENGTH_LONG).show();

      }
     }
     public void Exibir(View view){
        String exibir="";
        for(int contador =0; contador<=2; contador++){
            exibir=exibir+"Indice" + contador +
                    " - Nome: " + nome[contador]+
                    " - Celular: "+ celular[contador] +
                    " - Email: "+ email[contador] + "\n";
        }
        txtExibir.setText(exibir);
     }
    }


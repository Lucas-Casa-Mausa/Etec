package com.example.appgestaovendas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import Util.DBGestaoVendas;

public class ActCadProdutos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act_cad_produtos);
    }

        public class CadProdutos  extends AppCompatActivity {
            EditText edtCodigo, edtDescricao, edtUnidade, edtPreco,edtEstoque,edtCusto;
            Button btnCadastrar,btnAlterar,btnExcluir,btnConsultar;

            private int codigo=0;

            DBGestaoVendas dbgestaovendas =null;
            SQLiteDatabase db =null ;
            ContentValues valores = null;
            Cursor cursor;

            @Override
            protected  void onCreate(Bundle savedInstanceState){
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_act_cad_produtos);
                edtCodigo=findViewById(R.id.edtCodigo);
                edtDescricao=findViewById(R.id.edtDescricao);
                edtUnidade=findViewById(R.id.edtUnidade);
                edtPreco=findViewById(R.id.edtPreco);
                edtEstoque=findViewById(R.id.edtEstoque);
                edtCusto=findViewById(R.id.edtCusto);
                btnCadastrar=findViewById(R.id.btnCadastrar);
                btnAlterar=findViewById(R.id.btnAlterar);
                btnExcluir=findViewById(R.id.btnExcluir);
                btnConsultar=findViewById(R.id.btnConsultar);
                dbgestaovendas = new DBGestaoVendas(getBaseContext());
            }

            public void Limpar(View view){
                edtCodigo.setText("");
                edtDescricao.setText("");
                edtUnidade.setText("");
                edtPreco.setText("");
                edtEstoque.setText("");
                edtCusto.setText("");

            }

            public  void Cadastrar(View view){
                db=dbgestaovendas.getWritableDatabase();
                valores= new ContentValues();
                valores.put("codigo",edtCodigo.getText().toString());
                valores.put("descricao",edtDescricao.getText().toString());
                valores.put("unidade",edtUnidade.getText().toString());
                valores.put("preco",edtPreco.getText().toString());
                valores.put("estoque",edtEstoque.getText().toString());
                valores.put("custo",edtCusto.getText().toString());
                double linha =db.insert("produto",null,valores);
                if(linha==0){
                    Toast.makeText(this, "Falha ao cadastrar", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(this, "Cadastro realizado com sucesso", Toast.LENGTH_SHORT).show();
                }
                db.close();
                Limpar(view);
            }

            public void Consultarcodigo(View view){
                db=dbgestaovendas.getReadableDatabase();
                cursor=db.rawQuery("select * from produto where codigo="+ Integer.parseInt(edtCodigo.getText().toString().trim()),null);

                if(cursor.moveToFirst()){
                    edtCodigo.setText(cursor.getString(1));
                    edtDescricao.setText(cursor.getString(2));
                    edtUnidade.setText(cursor.getString(3));
                    edtPreco.setText(cursor.getString(4));
                    edtEstoque.setText(cursor.getString(5));
                    edtCusto.setText(cursor.getString(6));
                }
                else{
                    Toast.makeText(this, "Consulta vazia", Toast.LENGTH_SHORT).show();
                }
                db.close();
            }


        }

    }

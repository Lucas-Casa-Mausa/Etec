package Util;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBGestaoVendas  extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private  static final String DATABASE_NAME="dbgestaovendas.db";

    private String tblproduto =" create table if not exists produto" +
            "(codigo integer primary key autoincrement,"+
            "descricao varchar(40),"+
            "unidade varchar (2),"+
            "preco numeric,"+
            "estoque numeric,"+
            "custo numeric);";

    public DBGestaoVendas (Context contexto){
        super(contexto,DATABASE_NAME,null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL(tblproduto);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,int oldversion,int newversion){

    }


}
